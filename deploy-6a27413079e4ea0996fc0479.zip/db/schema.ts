import { pgTable, serial, text, timestamp, boolean, integer } from "drizzle-orm/pg-core";

export const testimonials = pgTable("testimonials", {
  id: serial().primaryKey(),
  name: text().notNull(),
  dogName: text("dog_name"),
  message: text().notNull(),
  rating: integer().default(5),
  approved: boolean().default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});
