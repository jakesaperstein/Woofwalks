import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { testimonials } from "../../db/schema.js";
import { eq, desc } from "drizzle-orm";

export default async (req: Request) => {
  if (req.method === "GET") {
    const approved = await db
      .select({
        id: testimonials.id,
        name: testimonials.name,
        dogName: testimonials.dogName,
        message: testimonials.message,
        rating: testimonials.rating,
        createdAt: testimonials.createdAt,
      })
      .from(testimonials)
      .where(eq(testimonials.approved, true))
      .orderBy(desc(testimonials.createdAt));

    return Response.json(approved);
  }

  if (req.method === "POST") {
    let body: { name?: string; dogName?: string; message?: string; rating?: number };
    try {
      body = await req.json();
    } catch {
      return new Response("Invalid JSON", { status: 400 });
    }

    const { name, dogName, message, rating } = body;

    if (!name?.trim() || !message?.trim()) {
      return new Response("Name and message are required", { status: 400 });
    }

    if (name.trim().length > 100 || message.trim().length > 1000) {
      return new Response("Name or message is too long", { status: 400 });
    }

    const clampedRating = rating && rating >= 1 && rating <= 5 ? Math.round(rating) : 5;

    const [inserted] = await db
      .insert(testimonials)
      .values({
        name: name.trim(),
        dogName: dogName?.trim() || null,
        message: message.trim(),
        rating: clampedRating,
        approved: false,
      })
      .returning({ id: testimonials.id });

    return Response.json(
      { success: true, id: inserted.id, message: "Thank you! Your testimonial is pending review." },
      { status: 201 }
    );
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: "/api/testimonials",
};
