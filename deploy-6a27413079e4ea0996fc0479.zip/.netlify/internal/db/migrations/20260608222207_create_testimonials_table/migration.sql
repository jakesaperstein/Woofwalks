CREATE TABLE "testimonials" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"dog_name" text,
	"message" text NOT NULL,
	"rating" integer DEFAULT 5,
	"approved" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now()
);
